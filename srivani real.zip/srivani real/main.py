from fastapi import FastAPI, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import json
import uuid

# Load environment variables
load_dotenv()

app = FastAPI(
    title="MindEase - Mental Health Support",
    description="AI-powered mental health support system with mood tracking",
    version="1.0.0"
)

# Setup templates
templates = Jinja2Templates(directory="templates")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage (in production, use a database)
if not os.path.exists('data'):
    os.makedirs('data')

# Initialize Google's Generative AI
try:
    genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
    model = genai.GenerativeModel('gemini-pro')
    chat = model.start_chat(history=[])
except Exception as e:
    print(f"Error initializing Gemini: {e}")
    raise

# Models
class Message(BaseModel):
    content: str
    sender: str = "user"
    session_id: Optional[str] = None

class AssessmentResponse(BaseModel):
    message: str
    resources: List[str] = []
    needs_immediate_help: bool = False
    session_id: Optional[str] = None

class MoodEntry(BaseModel):
    mood: str
    note: Optional[str] = None
    timestamp: str
    session_id: str

# Helper functions
def get_session_id(request: Request) -> str:
    """Get or create a session ID for the user"""
    if not hasattr(request.state, 'session_id'):
        request.state.session_id = str(uuid.uuid4())
    return request.state.session_id

def save_mood_entry(entry: MoodEntry):
    """Save mood entry to a JSON file"""
    filepath = os.path.join('data', 'mood_entries.json')
    entries = []
    
    if os.path.exists(filepath):
        with open(filepath, 'r') as f:
            try:
                entries = json.load(f)
            except json.JSONDecodeError:
                entries = []
    
    entries.append(entry.dict())
    
    with open(filepath, 'w') as f:
        json.dump(entries, f, indent=2)

def get_mood_history(session_id: str) -> List[Dict[str, Any]]:
    """Get mood history for a session"""
    filepath = os.path.join('data', 'mood_entries.json')
    if not os.path.exists(filepath):
        return []
    
    with open(filepath, 'r') as f:
        try:
            entries = json.load(f)
            return [e for e in entries if e.get('session_id') == session_id][:30]  # Return last 30 entries
        except json.JSONDecodeError:
            return []

def generate_ai_response(message: str, context: str = "") -> Dict[str, Any]:
    """Generate AI response using Gemini"""
    try:
        prompt = f"""You are a compassionate mental health support assistant for students. 
        Be empathetic, supportive, and non-judgmental. Keep responses concise but helpful.
        
        {context}
        
        User: {message}
        Assistant: """
        
        response = model.generate_content(prompt)
        return {"message": response.text, "resources": [], "needs_immediate_help": False}
    except Exception as e:
        print(f"Error generating AI response: {e}")
        return {
            "message": "I apologize, but I'm having trouble processing your request right now. Please try again later.",
            "resources": [],
            "needs_immediate_help": False
        }

# Routes
@app.get("/")
async def root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/chat", response_model=AssessmentResponse)
async def chat(message: Message, request: Request):
    try:
        # Get or create session ID
        session_id = message.session_id or get_session_id(request)
        
        # Check for emergency keywords
        needs_help = any(word in message.content.lower() for word in 
                        ['suicide', 'harm', 'emergency', 'help', 'urgent', 'hurt myself', 'not safe'])
        
        # Generate AI response
        context = f"""
        User's previous messages in this session: {message.content[:500]}
        Current time: {datetime.now().strftime('%Y-%m-%d %H:%M')}
        """
        
        ai_response = generate_ai_response(message.content, context)
        
        # Get resource recommendations if needed
        if any(word in message.content.lower() for word in ['resource', 'help', 'support', 'counseling']):
            resource_prompt = """
            Based on the user's message, suggest 1-2 specific university mental health resources 
            that would be most helpful. Keep each suggestion very brief (max 10 words).
            Format as a bullet list with each item on a new line starting with a dash.
            If no relevant resources, return an empty list.
            
            User's message: """ + message.content[:300]
            
            resource_response = model.generate_content(resource_prompt)
            resources = [line.strip('- ') for line in resource_response.text.split('\n') 
                        if line.strip().startswith('-')]
        else:
            resources = []
        
        return AssessmentResponse(
            message=ai_response.get("message", "I'm here to support you. Could you tell me more about how you're feeling?"),
            resources=resources[:3],  # Limit to 3 resources
            needs_immediate_help=needs_help,
            session_id=session_id
        )
    except Exception as e:
        print(f"Error in chat endpoint: {e}")
        return JSONResponse(
            status_code=500,
            content={"message": "I'm having trouble processing your request. Please try again.", "error": str(e)}
        )

# Mood Tracking Endpoints
@app.post("/api/mood")
async def log_mood(entry: MoodEntry, request: Request):
    try:
        session_id = get_session_id(request)
        entry.session_id = session_id
        entry.timestamp = datetime.now().isoformat()
        
        save_mood_entry(entry)
        
        # Generate a supportive response based on mood
        mood_responses = {
            "awful": "I'm really sorry you're feeling this way. Would you like to talk about what's bothering you?",
            "bad": "I'm here to listen. It's okay to feel this way. Would you like to share more?",
            "neutral": "Thanks for checking in. Would you like to explore what might help improve your day?",
            "good": "I'm glad you're doing well! What's been going well for you today?",
            "great": "That's wonderful to hear! Would you like to share what's making your day great?"
        }
        
        response_message = mood_responses.get(entry.mood, "Thank you for sharing how you're feeling.")
        
        return {
            "message": response_message,
            "mood": entry.mood,
            "timestamp": entry.timestamp
        }
        
    except Exception as e:
        print(f"Error logging mood: {e}")
        raise HTTPException(status_code=500, detail="Failed to log mood entry")

@app.get("/api/mood/history")
async def get_mood_history_endpoint(request: Request):
    try:
        session_id = get_session_id(request)
        history = get_mood_history(session_id)
        return {"history": history}
    except Exception as e:
        print(f"Error fetching mood history: {e}")
        return {"history": []}

# Emergency contact information
@app.get("/api/emergency-contacts")
async def get_emergency_contacts():
    return {
        "emergency_contacts": [
            "Campus Security: 911 (or your local emergency number)",
            "Crisis Text Line: Text HOME to 741741",
            "National Suicide Prevention Lifeline: 1-800-273-8255",
            "International Emergency Numbers: https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers"
        ]
    }

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
